package com.tcc.senai.help.dto;

import com.tcc.senai.help.entity.Endereco;
import com.tcc.senai.help.entity.UnidadeFederativa;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;

public record CilenteRequestDTO(
        @NotBlank(message = "campo nome não deve ser vazio")
        String nome,

        @NotBlank(message = "campo sobrenome não deve ser vazio")
        String sobrenome,

        @NotBlank(message = "campo email não deve ser vazio")
        @Email
        String email,

        @NotBlank(message = "campo senha não deve ser vazio")
        String senha,

        @NotNull(message = "campo data de nascimento não pode ser vazio")
        LocalDate dataNascimento,

        @NotNull(message = "campo endereço não pode ser vazio")
        Endereco endereco

                
) {
}

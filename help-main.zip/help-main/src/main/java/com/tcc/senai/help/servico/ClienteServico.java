package com.tcc.senai.help.servico;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.tcc.senai.help.dto.CilenteRequestDTO;
import com.tcc.senai.help.dto.ClienteResponseDTO;
import com.tcc.senai.help.entity.Cliente;
import com.tcc.senai.help.repository.ClienteRepository;

@Service
public class ClienteServico {
    
    @Autowired
    private ClienteRepository cr;

    public Iterable<Cliente> listar() {
        return cr.findAll();
    }

    public ResponseEntity<?> cadastrar(CilenteRequestDTO clienteDTO) {
        if (clienteDTO.email() == null || clienteDTO.email().trim().isEmpty()) {
            return ResponseEntity.badRequest().body("O email do cliente é obrigatório!");
        } else if (clienteDTO.senha() == null || clienteDTO.senha().trim().isEmpty()) {
            return ResponseEntity.badRequest().body("A senha do cliente é obrigatória!");
        } else {
            Cliente cliente = new Cliente();
            cliente.setNome(clienteDTO.nome());
            cliente.setSobrenome(clienteDTO.sobrenome());
            cliente.setEmail(clienteDTO.email());
            cliente.setSenha(clienteDTO.senha());
            cliente.setDataNascimento(clienteDTO.dataNascimento());
            cliente.setEndereco(clienteDTO.endereco());
            
            cr.save(cliente);
            return ResponseEntity.ok("Cliente cadastrado com sucesso!");
        }
    }

    public ResponseEntity<?> login(String email, String senha) {
        Cliente cliente = cr.findByEmail(email);
        if (cliente != null && cliente.getSenha().equals(senha)) {
            ClienteResponseDTO responseDTO = new ClienteResponseDTO(
                cliente.getId(),
                cliente.getNome(),
                cliente.getSobrenome(),
                cliente.getEmail(),
                cliente.getEndereco()
            );
            return ResponseEntity.ok(responseDTO);
        } else {
            return ResponseEntity.badRequest().body("Email ou senha incorretos!");
        }
    }

    public ResponseEntity<String> remover(long id) {
        cr.deleteById(id);  
        return ResponseEntity.ok("Cliente removido com sucesso!");
    }
}
package com.tcc.senai.help.servico;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.tcc.senai.help.dto.PrestadorRequestDTO;
import com.tcc.senai.help.dto.PrestadorResponseDTO;
import com.tcc.senai.help.entity.Prestador;
import com.tcc.senai.help.repository.PrestadorRepository;

@Service
public class PrestadorServico {
    
    @Autowired
    private PrestadorRepository pr;

    public Iterable<Prestador> listar() {
        return pr.findAll();
    }

    public ResponseEntity<?> cadastrar(PrestadorRequestDTO prestadorDTO) {
        if (prestadorDTO.email() == null || prestadorDTO.email().trim().isEmpty()) {
            return ResponseEntity.badRequest().body("O email do prestador é obrigatório!");
        } else if (prestadorDTO.senha() == null || prestadorDTO.senha().trim().isEmpty()) {
            return ResponseEntity.badRequest().body("A senha do prestador é obrigatória!");
        } else if (prestadorDTO.telefone() == null || prestadorDTO.telefone().trim().isEmpty()) {
            return ResponseEntity.badRequest().body("O telefone do prestador é obrigatório!");
        } else {
            Prestador prestador = new Prestador();
            prestador.setNome(prestadorDTO.nome());
            prestador.setSobrenome(prestadorDTO.sobrenome());
            prestador.setEmail(prestadorDTO.email());
            prestador.setSenha(prestadorDTO.senha());
            prestador.setTelefone(prestadorDTO.telefone());
            prestador.setEndereco(prestadorDTO.endereco());
            
            pr.save(prestador);
            return ResponseEntity.ok("Prestador cadastrado com sucesso!");
        }
    }

    public ResponseEntity<?> login(String email, String senha) {
        Prestador prestador = pr.findByEmail(email);
        if (prestador != null && prestador.getSenha().equals(senha)) {
            PrestadorResponseDTO responseDTO = new PrestadorResponseDTO(
                prestador.getId(),
                prestador.getNome(),
                prestador.getSobrenome(),
                prestador.getTelefone(),
                prestador.getEmail(),
                prestador.getSenha(),
                prestador.getEndereco()
            );
            return ResponseEntity.ok(responseDTO);
        } else {
            return ResponseEntity.badRequest().body("Email ou senha incorretos!");
        }
    }

    public ResponseEntity<String> remover(long id) {
        pr.deleteById(id);  
        return ResponseEntity.ok("Prestador removido com sucesso!");
    }
}
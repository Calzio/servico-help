package com.tcc.senai.help.dto;

import com.tcc.senai.help.entity.Endereco;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

public record PrestadorResponseDTO(
    Long id,
    String nome,
    String sobrenome,
    String telefone,
    String email,
    String senha,
    Endereco endereco
) {

}

package com.tcc.senai.help.repository;

import com.tcc.senai.help.entity.Prestador;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PrestadorRepository extends JpaRepository<Prestador, Long> {
    Prestador findByEmail(String email);
}

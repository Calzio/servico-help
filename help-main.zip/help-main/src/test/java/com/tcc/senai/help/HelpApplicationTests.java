package com.tcc.senai.help;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelpApplicationTests {

	@Test
	void contextLoads() {
	}

}
